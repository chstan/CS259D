Conrad Stansbury	chstan@stanford.edu
Dennis Wang			dwang22@stanford.edu

Time breakdown:
P1:
	Conrad - research, 5hrs
	Dennis - consulting, 0.5hrs

P2:
	Conrad - implementation, research, ~20hrs
	Dennis - research, minor implementation, consulting, 3hrs

P3:
	Dennis - implementation, research, ~10 hrs
	Conrad - consulting, 1hrs

Thoughts:
P1:
N/A

P2:
Interesting algorithm for P2. There were many changes we needed to make so that it wasn't computationally prohibitive, but hopefully we are still in keeping with the spirit of the approach as outlined in the paper. Though we do wonder how the authors of the paper implemented their work.

P3:
Pretty fun mini-project, quite enjoyed doing research into this. We feel like results could have been much better if the password/typed sequence from training set were longer.

Conrad Stansbury	chstan@stanford.edu
Dennis Wang			dwang22@stanford.edu

Time breakdown:
P1:
	Conrad - 3hrs
	Dennis - 2hrs

P2:
	Conrad - everything, 10hrs

P3:
	Dennis - everything, 6hrs

Thoughts:
P1:
N/A

P2:
It took a long time to train all the classifiers.

P3:
Entropy doesn't seem very well-suited to the task (as explained more in depth in my analysis).
